
package com.example.materialmanager;
import android.app.*; import android.os.*; import android.graphics.Color; import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
    LinearLayout list; ArrayList<String[]> data=new ArrayList<>();
    android.content.SharedPreferences sp;
    public void onCreate(Bundle b){super.onCreate(b); sp=getSharedPreferences("m",0); load(); build();}
    void load(){String s=sp.getString("data",""); if(s.isEmpty()){data.add(new String[]{"الجبهات","350","6","قطعة"});data.add(new String[]{"الجبهات","390","4","قطعة"});data.add(new String[]{"مجاري","طول 4 أمتار","6","قطعة"});data.add(new String[]{"بوري إنج سميك","—","10","قطعة"});data.add(new String[]{"راصور","طول 4 أمتار","5","كراتين"});data.add(new String[]{"طووس مع بيليات","—","60","قطعة"});data.add(new String[]{"مسكات","—","20","قطعة"});}else{for(String r:s.split("\\n",-1)){if(!r.isEmpty())data.add(r.split("\\|",-1));}}}
    void save(){StringBuilder x=new StringBuilder();for(String[] r:data)x.append(String.join("|",r)).append("\n");sp.edit().putString("data",x.toString()).apply();}
    TextView t(String x,int z){TextView v=new TextView(this);v.setText(x);v.setTextSize(z);v.setPadding(18,16,18,16);return v;}
    void build(){LinearLayout base=new LinearLayout(this);base.setOrientation(LinearLayout.VERTICAL);base.setPadding(18,18,18,10);
      TextView title=t("📦 إدارة المواد",24);title.setGravity(Gravity.CENTER);base.addView(title);
      Button add=new Button(this);add.setText("➕ إضافة مادة");add.setOnClickListener(v->dialog(-1));base.addView(add);
      list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL); ScrollView sv=new ScrollView(this);sv.addView(list);base.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
      TextView dev=t("المطوّر: محمد فاتح",14);dev.setGravity(Gravity.CENTER);base.addView(dev);setContentView(base);refresh();}
    void refresh(){list.removeAllViews(); for(int i=0;i<data.size();i++){final int k=i;LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
      String[] r=data.get(i); TextView v=t(r[0]+"  |  "+r[1]+"  |  "+r[2]+" "+r[3],16);row.addView(v,new LinearLayout.LayoutParams(0,-2,1));
      Button e=new Button(this);e.setText("تعديل");e.setOnClickListener(x->dialog(k));row.addView(e);
      Button d=new Button(this);d.setText("حذف");d.setOnClickListener(x->{data.remove(k);save();refresh();});row.addView(d);list.addView(row);}
      TextView sum=t("المواد المسجلة: "+data.size(),16);sum.setGravity(Gravity.CENTER);list.addView(sum);}
    void dialog(int idx){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(25,5,25,5);
      EditText n=new EditText(this);n.setHint("اسم المادة");EditText q=new EditText(this);q.setHint("القياس");EditText c=new EditText(this);c.setHint("العدد");EditText u=new EditText(this);u.setHint("الوحدة: قطعة / كرتون / متر");
      l.addView(n);l.addView(q);l.addView(c);l.addView(u); if(idx>=0){String[] r=data.get(idx);n.setText(r[0]);q.setText(r[1]);c.setText(r[2]);u.setText(r[3]);}
      new AlertDialog.Builder(this).setTitle(idx<0?"إضافة مادة":"تعديل مادة").setView(l).setPositiveButton("حفظ",(d,w)->{String[] r={n.getText().toString(),q.getText().toString(),c.getText().toString(),u.getText().toString()};if(idx<0)data.add(r);else data.set(idx,r);save();refresh();}).setNegativeButton("إلغاء",null).show();}
}
